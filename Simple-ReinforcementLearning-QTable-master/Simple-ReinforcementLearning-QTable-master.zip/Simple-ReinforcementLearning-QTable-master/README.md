# Simple-RL-QTable


Simple Reinforcement Learning using Q tables. Train an agent to move to its destination


![](Q_test6.gif)



**Dependancy modules:<br/>**
- numpy<br/>
- pandas<br/>
- time<br/>
- tkinter - for display purpose<br/>


Just execute the following to train or test:<br/>
>**python test_env.py**
