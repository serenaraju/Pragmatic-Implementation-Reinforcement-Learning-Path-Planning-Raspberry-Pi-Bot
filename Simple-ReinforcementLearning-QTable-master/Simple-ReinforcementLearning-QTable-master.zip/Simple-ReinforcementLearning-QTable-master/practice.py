col_num = 9
row_num = 9
col_list = list(range(0,col_num))
row_list = list(range(0,row_num))
print(col_list,row_list)